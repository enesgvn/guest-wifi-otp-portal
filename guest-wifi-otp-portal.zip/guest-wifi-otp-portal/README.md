# Guest Wi-Fi OTP Portal

Self-hosted guest Wi-Fi SMS OTP portal with FortiGate API integration, PostgreSQL audit logs, IP/MAC session tracking, and automated cleanup.

This repository is **fully sanitized**. It does not contain organization names, real domains, real firewall addresses, production tokens, phone numbers, customer logs, or company-specific configuration.

## What it does

1. A guest client connects to a guest SSID or VLAN.
2. The firewall redirects the client to this Flask portal.
3. The user enters name and phone number.
4. The portal sends an OTP code through an SMS provider.
5. After verification, the portal creates a FortiGate address object for the client's IP.
6. The IP object is added to a configured FortiGate address group.
7. A scheduled sync job validates IP/MAC consistency and removes expired or unsafe sessions.

## Key features

- Flask web portal
- PostgreSQL-backed session and audit records
- SMS OTP flow with rate limiting
- CSRF protection for OTP requests
- FortiGate API address object/group integration
- FortiGate DHCP monitor lookup for MAC address discovery
- IP + MAC validation
- Expired session cleanup
- Cleanup when a verified IP is later assigned to a different MAC
- Optional permanent sessions with MAC-aware IP move support
- Basic admin panel
- Daily SHA-256 integrity chain for audit support
- Docker and systemd deployment examples
- GitHub Actions syntax check

## Architecture

```text
Guest Device -> Guest SSID/VLAN -> Firewall Captive Portal -> Flask OTP Portal
                                                                  |
                                                                  +-> PostgreSQL
                                                                  +-> SMS Provider API
                                                                  +-> FortiGate API
```

## Repository layout

```text
.
├── app.py
├── sync_fortigate_leases.py
├── generate_integrity_hash.py
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
├── templates/
├── static/
├── docs/
├── cron/
├── systemd/
└── db/
```

## Quick start with Docker

```bash
git clone https://github.com/YOUR_USERNAME/guest-wifi-otp-portal.git
cd guest-wifi-otp-portal
cp .env.example .env
nano .env
docker compose up -d --build
```

Initialize the database:

```bash
docker compose exec app python -c "from app import init_db; init_db(); print('Database initialized')"
```

Open the portal:

```text
http://localhost:8080
```

Admin panel:

```text
http://localhost:8080/admin
```

## Manual Linux installation

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip postgresql postgresql-contrib
sudo mkdir -p /opt/guest-wifi-otp-portal
sudo chown $USER:$USER /opt/guest-wifi-otp-portal
cd /opt/guest-wifi-otp-portal
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Create database:

```sql
CREATE DATABASE guestportal;
CREATE USER guestuser WITH PASSWORD 'change-me';
GRANT ALL PRIVILEGES ON DATABASE guestportal TO guestuser;
```

Initialize tables:

```bash
source venv/bin/activate
python -c "from app import init_db; init_db(); print('Database initialized')"
```

Run:

```bash
gunicorn -w 2 -b 0.0.0.0:8080 app:app
```

## FortiGate configuration summary

Create an address group, for example:

```text
Guest_SMS_Allowed
```

The application creates address objects like:

```text
GUEST_10_20_30_40
```

Recommended policies:

```text
1. Guest interface -> Portal server, service TCP/8080, accept
2. Guest interface -> WAN, source Guest_SMS_Allowed, NAT enabled, accept
3. Guest interface -> internal networks, deny
```

See `docs/fortigate-notes.md` for details.

## Environment variables

Copy `.env.example` to `.env` and edit values. Never commit `.env`.

```env
FORTIGATE_HOST=https://firewall.example.local
FORTIGATE_API_TOKEN=replace-with-api-token
FORTIGATE_ALLOWED_GROUP=Guest_SMS_Allowed
GUEST_VALID_HOURS=12
SUCCESS_REDIRECT_URL=http://neverssl.com
```

## Scheduled jobs

Lease/IP/MAC sync every 5 minutes:

```cron
*/5 * * * * cd /opt/guest-wifi-otp-portal && /opt/guest-wifi-otp-portal/venv/bin/python /opt/guest-wifi-otp-portal/sync_fortigate_leases.py >> /opt/guest-wifi-otp-portal/integrity/lease_sync.log 2>&1
```

Daily integrity hash:

```cron
10 0 * * * cd /opt/guest-wifi-otp-portal && /opt/guest-wifi-otp-portal/venv/bin/python /opt/guest-wifi-otp-portal/generate_integrity_hash.py >> /opt/guest-wifi-otp-portal/integrity/hash_cron.log 2>&1
```

## IP/MAC safety logic

| Case | Action |
|---|---|
| Same IP + same MAC | Keep session |
| Same IP + different MAC | Remove from firewall group and mark `mac_mismatch` |
| DHCP lease not visible | Keep session temporarily and log warning |
| Session expired | Remove from firewall group and mark `expired` |
| Firewall group object without active DB session | Remove as orphan |
| Permanent session MAC found on a new IP | Move firewall access to the new IP |

## Security notes

- Do not commit `.env` or production logs.
- Use HTTPS in production.
- Restrict the FortiGate API account to the minimum required permissions.
- Replace the test SMS logger with a real SMS provider integration.
- Store secrets in a vault or deployment secret manager for production.
- Review data retention and consent text with your legal/compliance team.
- This project is a technical reference implementation, not legal advice.

## Sanitization checklist before public release

```bash
grep -RInE 'company-name|real-domain|real-phone|real-token|real-firewall-ip' . || true
find . -name '.env' -o -name '*.log' -o -path './integrity/*'
```

## License

MIT
