import os
from urllib.parse import quote
from datetime import datetime

import psycopg2
import requests
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))
DB_CONFIG = {"host": os.getenv("DB_HOST", "localhost"), "port": int(os.getenv("DB_PORT", "5432")), "dbname": os.getenv("DB_NAME", "guestportal"), "user": os.getenv("DB_USER", "guestuser"), "password": os.getenv("DB_PASSWORD", "")}
FORTIGATE_HOST = os.getenv("FORTIGATE_HOST", "").rstrip("/")
FORTIGATE_API_TOKEN = os.getenv("FORTIGATE_API_TOKEN", "")
FORTIGATE_ALLOWED_GROUP = os.getenv("FORTIGATE_ALLOWED_GROUP", "Guest_SMS_Allowed")
FORTIGATE_VERIFY_TLS = os.getenv("FORTIGATE_VERIFY_TLS", "false").lower() == "true"

def db_conn(): return psycopg2.connect(**DB_CONFIG)
def fortigate_headers(): return {"Authorization": f"Bearer {FORTIGATE_API_TOKEN}", "Content-Type": "application/json", "Accept": "application/json"}
def normalize_mac(mac): return None if not mac else str(mac).strip().upper().replace("-", ":")
def create_object_name(ip_address): return "GUEST_" + str(ip_address).replace(".", "_")
def log_system(cur, level, event_name, message, ip_address=None): cur.execute("INSERT INTO system_logs (level, event_name, message, ip_address) VALUES (%s, %s, %s, %s)", (level, event_name, message, ip_address))

def get_dhcp_leases():
    resp = requests.get(f"{FORTIGATE_HOST}/api/v2/monitor/system/dhcp", headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
    if resp.status_code != 200: raise RuntimeError(f"DHCP monitor read failed: {resp.status_code} - {resp.text}")
    results = resp.json().get("results", [])
    if isinstance(results, dict):
        leases = []
        for value in results.values():
            if isinstance(value, list): leases.extend(value)
        results = leases
    return {str(item.get("ip")): item for item in results if item.get("ip")}

def find_ip_by_mac(leases, mac_address):
    target = normalize_mac(mac_address)
    if not target: return None
    for ip_address, lease in leases.items():
        if normalize_mac(lease.get("mac")) == target: return ip_address
    return None

def add_ip_to_fortigate(ip_address):
    object_name = create_object_name(ip_address); encoded_group = quote(FORTIGATE_ALLOWED_GROUP, safe=""); encoded_object = quote(object_name, safe="")
    address_url = f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/address"; group_url = f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/addrgrp/{encoded_group}"
    payload = {"name": object_name, "type": "ipmask", "subnet": f"{ip_address} 255.255.255.255", "comment": "Created automatically by Guest Wi-Fi OTP Portal"}
    create_resp = requests.post(address_url, headers=fortigate_headers(), json=payload, verify=FORTIGATE_VERIFY_TLS, timeout=15)
    if create_resp.status_code not in [200, 201]:
        check_resp = requests.get(f"{address_url}/{encoded_object}", headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
        if check_resp.status_code != 200: return False, f"address create failed: {create_resp.status_code} - {create_resp.text}"
    group_resp = requests.get(group_url, headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
    if group_resp.status_code != 200: return False, f"group read failed: {group_resp.status_code} - {group_resp.text}"
    results = group_resp.json().get("results", [])
    if not results: return False, "group not found"
    names = []
    for member in results[0].get("member", []):
        name = member.get("name") if isinstance(member, dict) else None
        if name and name not in names: names.append(name)
    if object_name not in names: names.append(object_name)
    update_resp = requests.put(group_url, headers=fortigate_headers(), json={"member": [{"name": name} for name in names]}, verify=FORTIGATE_VERIFY_TLS, timeout=15)
    if update_resp.status_code not in [200, 201]: return False, f"group update failed: {update_resp.status_code} - {update_resp.text}"
    return True, object_name

def remove_ip_from_fortigate(ip_address):
    object_name = create_object_name(ip_address); encoded_group = quote(FORTIGATE_ALLOWED_GROUP, safe=""); encoded_object = quote(object_name, safe=""); group_url = f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/addrgrp/{encoded_group}"
    group_resp = requests.get(group_url, headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
    if group_resp.status_code != 200: return False, f"group read failed: {group_resp.status_code}"
    results = group_resp.json().get("results", [])
    if results:
        new_members = []
        for member in results[0].get("member", []):
            name = member.get("name") if isinstance(member, dict) else None
            if name and name != object_name: new_members.append({"name": name})
        update_resp = requests.put(group_url, headers=fortigate_headers(), json={"member": new_members}, verify=FORTIGATE_VERIFY_TLS, timeout=15)
        if update_resp.status_code not in [200, 201]: return False, f"group update failed: {update_resp.status_code} - {update_resp.text}"
    del_resp = requests.delete(f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/address/{encoded_object}", headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
    if del_resp.status_code not in [200, 404]: return False, f"address delete failed: {del_resp.status_code} - {del_resp.text}"
    return True, object_name

def main():
    conn = db_conn(); cur = conn.cursor(); leases = get_dhcp_leases()
    cur.execute("SELECT id, full_name, phone, ip_address::text, mac_address, expire_time, status FROM guest_sessions WHERE status IN ('active', 'permanent') ORDER BY id ASC"); sessions = cur.fetchall()
    checked = expired_removed = mac_saved = mac_mismatch_removed = permanent_moved = orphan_removed = 0
    for row in sessions:
        session_id, full_name, phone, ip_address, db_mac, expire_time, status = row; db_mac = normalize_mac(db_mac); checked += 1
        if status != "permanent" and expire_time and expire_time < datetime.now():
            ok, msg = remove_ip_from_fortigate(ip_address); cur.execute("UPDATE guest_sessions SET status='expired', logout_time=CURRENT_TIMESTAMP WHERE id=%s", (session_id,)); log_system(cur, "INFO", "session_expired_removed", f"Expired session removed. ID={session_id}, IP={ip_address}, Result={msg}", ip_address); expired_removed += 1; continue
        lease = leases.get(ip_address)
        if not lease:
            if status == "permanent" and db_mac:
                new_ip = find_ip_by_mac(leases, db_mac)
                if new_ip and new_ip != ip_address:
                    remove_ip_from_fortigate(ip_address); ok, msg = add_ip_to_fortigate(new_ip)
                    if ok: cur.execute("UPDATE guest_sessions SET ip_address=%s, fortigate_object_name=%s WHERE id=%s", (new_ip, create_object_name(new_ip), session_id)); log_system(cur, "INFO", "permanent_session_ip_moved", f"Permanent session moved to new IP. ID={session_id}, old={ip_address}, new={new_ip}", new_ip); permanent_moved += 1; continue
            log_system(cur, "WARNING", "dhcp_lease_not_found_keep_session", f"DHCP lease not visible. Session kept. ID={session_id}, IP={ip_address}", ip_address); continue
        current_mac = normalize_mac(lease.get("mac"))
        if not current_mac: log_system(cur, "WARNING", "dhcp_mac_empty_keep_session", f"DHCP lease MAC empty. Session kept. ID={session_id}, IP={ip_address}", ip_address); continue
        if not db_mac: cur.execute("UPDATE guest_sessions SET mac_address=%s WHERE id=%s", (current_mac, session_id)); log_system(cur, "INFO", "session_mac_saved", f"MAC saved. ID={session_id}, IP={ip_address}, MAC={current_mac}", ip_address); mac_saved += 1; continue
        if db_mac != current_mac:
            if status == "permanent":
                new_ip = find_ip_by_mac(leases, db_mac)
                if new_ip and new_ip != ip_address:
                    remove_ip_from_fortigate(ip_address); ok, msg = add_ip_to_fortigate(new_ip)
                    if ok: cur.execute("UPDATE guest_sessions SET ip_address=%s, fortigate_object_name=%s WHERE id=%s", (new_ip, create_object_name(new_ip), session_id)); log_system(cur, "INFO", "permanent_session_ip_moved", f"Permanent session moved after IP/MAC mismatch. ID={session_id}, old={ip_address}, new={new_ip}", new_ip); permanent_moved += 1; continue
            ok, msg = remove_ip_from_fortigate(ip_address); cur.execute("UPDATE guest_sessions SET status='mac_mismatch', logout_time=CURRENT_TIMESTAMP WHERE id=%s", (session_id,)); log_system(cur, "WARNING", "mac_mismatch_removed", f"IP moved to another MAC. Session removed. ID={session_id}, IP={ip_address}, old={db_mac}, new={current_mac}, Result={msg}", ip_address); mac_mismatch_removed += 1; continue
    encoded_group = quote(FORTIGATE_ALLOWED_GROUP, safe=""); group_url = f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/addrgrp/{encoded_group}"; group_resp = requests.get(group_url, headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
    if group_resp.status_code == 200:
        results = group_resp.json().get("results", [])
        if results:
            for member in results[0].get("member", []):
                member_name = member.get("name", "") if isinstance(member, dict) else ""
                if member_name.startswith("GUEST_"):
                    ip_from_object = member_name.replace("GUEST_", "").replace("_", "."); cur.execute("SELECT COUNT(*) FROM guest_sessions WHERE ip_address::text=%s AND status IN ('active','permanent')", (ip_from_object,))
                    if cur.fetchone()[0] == 0: ok, msg = remove_ip_from_fortigate(ip_from_object); log_system(cur, "WARNING", "orphan_fortigate_member_removed", f"Orphan FortiGate member removed. IP={ip_from_object}, Result={msg}", ip_from_object); orphan_removed += 1
    log_system(cur, "INFO", "lease_sync_completed", f"Lease sync completed. Checked={checked}, MAC saved={mac_saved}, MAC mismatch removed={mac_mismatch_removed}, permanent moved={permanent_moved}, expired removed={expired_removed}, orphan removed={orphan_removed}", None)
    conn.commit(); cur.close(); conn.close()
    print("Lease sync completed."); print("Checked:", checked); print("MAC saved:", mac_saved); print("MAC mismatch removed:", mac_mismatch_removed); print("Permanent sessions moved:", permanent_moved); print("Expired removed:", expired_removed); print("Orphan removed:", orphan_removed)

if __name__ == "__main__": main()
