import os
import re
import secrets
from urllib.parse import quote
from datetime import datetime, timedelta

import psycopg2
import requests
from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, session

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", secrets.token_urlsafe(32))

DB_CONFIG = {"host": os.getenv("DB_HOST", "localhost"), "port": int(os.getenv("DB_PORT", "5432")), "dbname": os.getenv("DB_NAME", "guestportal"), "user": os.getenv("DB_USER", "guestuser"), "password": os.getenv("DB_PASSWORD", "")}
GUEST_VALID_HOURS = int(os.getenv("GUEST_VALID_HOURS", "12"))
OTP_EXPIRE_MINUTES = int(os.getenv("OTP_EXPIRE_MINUTES", "5"))
OTP_MAX_TRY = int(os.getenv("OTP_MAX_TRY", "3"))
SMS_RESEND_SECONDS = int(os.getenv("SMS_RESEND_SECONDS", "60"))
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-me")
SUCCESS_REDIRECT_URL = os.getenv("SUCCESS_REDIRECT_URL", "http://neverssl.com")
FORTIGATE_HOST = os.getenv("FORTIGATE_HOST", "").rstrip("/")
FORTIGATE_API_TOKEN = os.getenv("FORTIGATE_API_TOKEN", "")
FORTIGATE_ALLOWED_GROUP = os.getenv("FORTIGATE_ALLOWED_GROUP", "Guest_SMS_Allowed")
FORTIGATE_VERIFY_TLS = os.getenv("FORTIGATE_VERIFY_TLS", "false").lower() == "true"


def db_conn():
    return psycopg2.connect(**DB_CONFIG)


def init_db():
    conn = db_conn(); cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS guest_otp (id SERIAL PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT NOT NULL, otp_code TEXT NOT NULL, ip_address INET NOT NULL, user_agent TEXT, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, expires_at TIMESTAMP NOT NULL, verified BOOLEAN NOT NULL DEFAULT FALSE, try_count INTEGER NOT NULL DEFAULT 0)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS guest_sessions (id SERIAL PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT NOT NULL, ip_address INET NOT NULL, mac_address TEXT, status TEXT NOT NULL DEFAULT 'active', fortigate_object_name TEXT, login_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, expire_time TIMESTAMP, logout_time TIMESTAMP, retention_until TIMESTAMP NOT NULL)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS blocked_macs (id SERIAL PRIMARY KEY, mac_address TEXT NOT NULL UNIQUE, reason TEXT, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS system_logs (id SERIAL PRIMARY KEY, level TEXT NOT NULL, event_name TEXT NOT NULL, message TEXT NOT NULL, ip_address INET, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS integrity_hashes (id SERIAL PRIMARY KEY, hash_date DATE NOT NULL, source_name TEXT NOT NULL, record_count INTEGER NOT NULL, file_sha256 TEXT NOT NULL, chain_hash TEXT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    conn.commit(); cur.close(); conn.close()


def log_system(level, event_name, message, ip_address=None):
    try:
        conn = db_conn(); cur = conn.cursor()
        cur.execute("INSERT INTO system_logs (level, event_name, message, ip_address) VALUES (%s, %s, %s, %s)", (level, event_name, message, ip_address))
        conn.commit(); cur.close(); conn.close()
    except Exception as exc:
        print(f"LOG ERROR: {exc}", flush=True)


def get_client_ip():
    forwarded_for = request.headers.get("X-Forwarded-For")
    return forwarded_for.split(",")[0].strip() if forwarded_for else (request.remote_addr or "0.0.0.0")


def normalize_phone(raw_phone):
    digits = re.sub(r"\D", "", raw_phone or "")
    if digits.startswith("90") and len(digits) == 12: return digits
    if digits.startswith("0") and len(digits) == 11: return "9" + digits
    if digits.startswith("5") and len(digits) == 10: return "90" + digits
    return None


def mask_phone(phone):
    return phone if len(phone) < 6 else phone[:4] + "***" + phone[-2:]


def generate_otp():
    return f"{secrets.randbelow(1000000):06d}"


def generate_csrf_token():
    token = secrets.token_urlsafe(32); session["csrf_token"] = token; return token


def validate_csrf_token(token):
    session_token = session.get("csrf_token")
    return bool(token and session_token and secrets.compare_digest(token, session_token))


def can_send_sms(phone, ip_address):
    conn = db_conn(); cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM guest_otp WHERE phone = %s AND created_at > NOW() - INTERVAL '%s seconds'", (phone, SMS_RESEND_SECONDS))
    if cur.fetchone()[0] > 0: cur.close(); conn.close(); return False, "A verification code was sent recently. Please wait."
    cur.execute("SELECT COUNT(*) FROM guest_otp WHERE ip_address = %s AND created_at > NOW() - INTERVAL '10 minutes'", (ip_address,))
    if cur.fetchone()[0] >= 5: cur.close(); conn.close(); return False, "Too many requests from this IP address."
    cur.execute("SELECT COUNT(*) FROM guest_otp WHERE phone = %s AND created_at > NOW() - INTERVAL '1 day'", (phone,))
    if cur.fetchone()[0] >= 5: cur.close(); conn.close(); return False, "Daily SMS limit reached for this phone number."
    cur.close(); conn.close(); return True, "OK"


def save_otp(full_name, phone, otp_code, ip_address, user_agent):
    conn = db_conn(); cur = conn.cursor(); expires_at = datetime.now() + timedelta(minutes=OTP_EXPIRE_MINUTES)
    cur.execute("INSERT INTO guest_otp (full_name, phone, otp_code, ip_address, user_agent, expires_at) VALUES (%s, %s, %s, %s, %s, %s) RETURNING id", (full_name, phone, otp_code, ip_address, user_agent, expires_at))
    otp_id = cur.fetchone()[0]; conn.commit(); cur.close(); conn.close(); return otp_id


def send_sms(phone, message):
    print("==== TEST SMS MODE ====", flush=True); print("Phone:", phone, flush=True); print("Message:", message, flush=True); print("=======================", flush=True); return True


def verify_otp(otp_id, otp_code):
    conn = db_conn(); cur = conn.cursor()
    cur.execute("SELECT id, full_name, phone, otp_code, ip_address::text, expires_at, verified, try_count FROM guest_otp WHERE id = %s", (otp_id,))
    row = cur.fetchone()
    if not row: cur.close(); conn.close(); return False, "Verification record not found.", None
    row_id, full_name, phone, db_code, ip_address, expires_at, verified, try_count = row
    if verified: cur.close(); conn.close(); return False, "This code was already used.", None
    if expires_at < datetime.now(): cur.close(); conn.close(); return False, "The verification code expired.", None
    if try_count >= OTP_MAX_TRY: cur.close(); conn.close(); return False, "Too many invalid attempts.", None
    if otp_code != db_code:
        cur.execute("UPDATE guest_otp SET try_count = try_count + 1 WHERE id = %s", (otp_id,)); conn.commit(); cur.close(); conn.close(); return False, "Invalid verification code.", None
    cur.execute("UPDATE guest_otp SET verified = TRUE WHERE id = %s", (otp_id,)); conn.commit(); cur.close(); conn.close()
    return True, "OK", {"full_name": full_name, "phone": phone, "ip_address": ip_address}


def fortigate_ready():
    return bool(FORTIGATE_HOST and FORTIGATE_API_TOKEN and FORTIGATE_ALLOWED_GROUP)


def fortigate_headers():
    return {"Authorization": f"Bearer {FORTIGATE_API_TOKEN}", "Content-Type": "application/json", "Accept": "application/json"}


def create_object_name(ip_address):
    return "GUEST_" + str(ip_address).replace(".", "_")


def normalize_mac(mac):
    return None if not mac else str(mac).strip().upper().replace("-", ":")


def get_fortigate_dhcp_leases():
    if not fortigate_ready(): return {}
    resp = requests.get(f"{FORTIGATE_HOST}/api/v2/monitor/system/dhcp", headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
    if resp.status_code != 200:
        log_system("WARNING", "dhcp_lookup_failed", f"DHCP monitor read failed: {resp.status_code} - {resp.text}"); return {}
    results = resp.json().get("results", [])
    if isinstance(results, dict):
        flat = []
        for value in results.values():
            if isinstance(value, list): flat.extend(value)
        results = flat
    return {str(item.get("ip")): item for item in results if item.get("ip")}


def get_mac_from_fortigate(ip_address):
    lease = get_fortigate_dhcp_leases().get(str(ip_address))
    return normalize_mac(lease.get("mac")) if lease else None


def is_mac_blocked(mac_address):
    mac_address = normalize_mac(mac_address)
    if not mac_address: return False
    conn = db_conn(); cur = conn.cursor(); cur.execute("SELECT COUNT(*) FROM blocked_macs WHERE mac_address = %s", (mac_address,)); blocked = cur.fetchone()[0] > 0; cur.close(); conn.close(); return blocked


def add_ip_to_fortigate(ip_address):
    object_name = create_object_name(ip_address)
    if not fortigate_ready(): log_system("ERROR", "fortigate_config_missing", "FortiGate API settings are missing.", ip_address); return False, None
    try:
        payload = {"name": object_name, "type": "ipmask", "subnet": f"{ip_address} 255.255.255.255", "comment": "Created automatically by Guest Wi-Fi OTP Portal"}
        create_resp = requests.post(f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/address", headers=fortigate_headers(), json=payload, verify=FORTIGATE_VERIFY_TLS, timeout=15)
        if create_resp.status_code not in [200, 201]:
            encoded_object = quote(object_name, safe="")
            check_resp = requests.get(f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/address/{encoded_object}", headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
            if check_resp.status_code != 200:
                log_system("ERROR", "fortigate_address_create_failed", f"Address object create failed: {create_resp.status_code} - {create_resp.text}", ip_address); return False, None
        encoded_group = quote(FORTIGATE_ALLOWED_GROUP, safe=""); group_url = f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/addrgrp/{encoded_group}"
        group_resp = requests.get(group_url, headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
        if group_resp.status_code != 200: log_system("ERROR", "fortigate_group_get_failed", f"Address group read failed: {group_resp.status_code} - {group_resp.text}", ip_address); return False, None
        results = group_resp.json().get("results", [])
        if not results: log_system("ERROR", "fortigate_group_empty", f"Address group not found: {FORTIGATE_ALLOWED_GROUP}", ip_address); return False, None
        names = []
        for member in results[0].get("member", []):
            name = member.get("name") if isinstance(member, dict) else None
            if name and name not in names: names.append(name)
        if object_name not in names: names.append(object_name)
        update_resp = requests.put(group_url, headers=fortigate_headers(), json={"member": [{"name": name} for name in names]}, verify=FORTIGATE_VERIFY_TLS, timeout=15)
        if update_resp.status_code not in [200, 201]: log_system("ERROR", "fortigate_group_update_failed", f"Address group update failed: {update_resp.status_code} - {update_resp.text}", ip_address); return False, None
        verify_resp = requests.get(group_url, headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
        verify_names = [m.get("name") for m in verify_resp.json().get("results", [{}])[0].get("member", []) if isinstance(m, dict)] if verify_resp.status_code == 200 else []
        if object_name not in verify_names: log_system("ERROR", "fortigate_group_verify_missing", f"Object is not visible in address group: {object_name}", ip_address); return False, None
        log_system("INFO", "fortigate_ip_allowed", f"IP added to FortiGate group: {ip_address} -> {FORTIGATE_ALLOWED_GROUP}", ip_address); return True, object_name
    except Exception as exc:
        log_system("ERROR", "fortigate_exception", f"FortiGate exception: {exc}", ip_address); return False, None


def remove_ip_from_fortigate(ip_address):
    object_name = create_object_name(ip_address); encoded_group = quote(FORTIGATE_ALLOWED_GROUP, safe=""); encoded_object = quote(object_name, safe=""); group_url = f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/addrgrp/{encoded_group}"
    try:
        group_resp = requests.get(group_url, headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
        if group_resp.status_code == 200:
            results = group_resp.json().get("results", [])
            if results:
                new_members = []
                for member in results[0].get("member", []):
                    name = member.get("name") if isinstance(member, dict) else None
                    if name and name != object_name: new_members.append({"name": name})
                update_resp = requests.put(group_url, headers=fortigate_headers(), json={"member": new_members}, verify=FORTIGATE_VERIFY_TLS, timeout=15)
                if update_resp.status_code not in [200, 201]: return False, f"group update failed: {update_resp.status_code}"
        del_resp = requests.delete(f"{FORTIGATE_HOST}/api/v2/cmdb/firewall/address/{encoded_object}", headers=fortigate_headers(), verify=FORTIGATE_VERIFY_TLS, timeout=15)
        if del_resp.status_code not in [200, 404]: return False, f"address delete failed: {del_resp.status_code}"
        return True, object_name
    except Exception as exc:
        return False, str(exc)


def save_session(full_name, phone, ip_address, mac_address, fortigate_object_name):
    login_time = datetime.now(); expire_time = login_time + timedelta(hours=GUEST_VALID_HOURS); retention_until = login_time + timedelta(days=730)
    conn = db_conn(); cur = conn.cursor()
    cur.execute("INSERT INTO guest_sessions (full_name, phone, ip_address, mac_address, status, fortigate_object_name, login_time, expire_time, retention_until) VALUES (%s, %s, %s, %s, 'active', %s, %s, %s, %s) RETURNING id", (full_name, phone, ip_address, mac_address, fortigate_object_name, login_time, expire_time, retention_until))
    session_id = cur.fetchone()[0]; conn.commit(); cur.close(); conn.close(); return session_id, expire_time


@app.route("/", methods=["GET"])
def index(): return render_template("index.html", csrf_token=generate_csrf_token())


@app.route("/send-otp", methods=["POST"])
def send_otp_route():
    if not validate_csrf_token(request.form.get("csrf_token", "")): log_system("WARNING", "csrf_failed", "Invalid CSRF token", get_client_ip()); return "Invalid session request.", 403
    full_name = request.form.get("full_name", "").strip(); phone_raw = request.form.get("phone", "").strip(); consent = request.form.get("consent")
    if not full_name: return "Full name is required.", 400
    if consent != "on": return "You must accept the privacy notice.", 400
    phone_digits = re.sub(r"\D", "", phone_raw)
    if len(phone_digits) != 10 or not phone_digits.startswith("5"): return "Phone number must be 10 digits and start with 5.", 400
    phone = normalize_phone(phone_raw)
    if not phone: return "Invalid phone format.", 400
    ip_address = get_client_ip(); allowed, reason = can_send_sms(phone, ip_address)
    if not allowed: log_system("WARNING", "sms_rate_limited", reason, ip_address); return reason, 429
    otp_code = generate_otp(); otp_id = save_otp(full_name, phone, otp_code, ip_address, request.headers.get("User-Agent", "")); sms_message = f"Guest Wi-Fi verification code: {otp_code}. Valid for {OTP_EXPIRE_MINUTES} minutes."
    if not send_sms(phone, sms_message): log_system("ERROR", "sms_send_failed", f"SMS send failed: {phone}", ip_address); return "SMS could not be sent.", 500
    session["otp_id"] = otp_id; log_system("INFO", "otp_sent", f"OTP sent: {phone}", ip_address); return redirect(url_for("verify_page", phone=mask_phone(phone)))


@app.route("/verify", methods=["GET"])
def verify_page():
    if not session.get("otp_id"): return redirect(url_for("index"))
    return render_template("verify.html", phone=request.args.get("phone", ""))


@app.route("/verify-otp", methods=["POST"])
def verify_otp_route():
    otp_id = session.get("otp_id"); otp_code = request.form.get("otp_code", "").strip()
    if not otp_id: return redirect(url_for("index"))
    if not otp_code: return "Verification code is required.", 400
    ok, message, data = verify_otp(otp_id, otp_code)
    if not ok: return message, 400
    ip_address = data["ip_address"]; mac_address = get_mac_from_fortigate(ip_address)
    if mac_address and is_mac_blocked(mac_address): log_system("WARNING", "blocked_mac_attempt", f"Blocked MAC tried to log in: {mac_address}", ip_address); return "This device is blocked.", 403
    fg_ok, fg_object_name = add_ip_to_fortigate(ip_address)
    if not fg_ok: return "Verification succeeded, but network access could not be enabled.", 500
    session_id, expire_time = save_session(data["full_name"], data["phone"], ip_address, mac_address, fg_object_name); log_system("INFO", "guest_allowed", f"Guest allowed. Session ID: {session_id}", ip_address); session.pop("otp_id", None)
    return render_template("success.html", ip_address=ip_address, mac_address=mac_address or "Pending", expire_time=expire_time.strftime("%Y-%m-%d %H:%M"), redirect_url=SUCCESS_REDIRECT_URL)


def admin_required(): return session.get("admin_logged_in") is True


@app.route("/admin", methods=["GET", "POST"])
def admin_login():
    if request.method == "GET":
        if admin_required(): return redirect(url_for("admin_panel"))
        return render_template("admin_login.html")
    if request.form.get("username", "").strip() == ADMIN_USERNAME and request.form.get("password", "").strip() == ADMIN_PASSWORD:
        session.clear(); session["admin_logged_in"] = True; return redirect(url_for("admin_panel"))
    session.clear(); return render_template("admin_login.html", error="Invalid username or password.")


@app.route("/admin/panel")
def admin_panel():
    if not admin_required(): return redirect(url_for("admin_login"))
    conn = db_conn(); cur = conn.cursor()
    cur.execute("SELECT id, full_name, phone, ip_address::text, mac_address, status, login_time, expire_time FROM guest_sessions ORDER BY id DESC LIMIT 100"); sessions = cur.fetchall()
    cur.execute("SELECT id, level, event_name, message, ip_address::text, created_at FROM system_logs ORDER BY id DESC LIMIT 100"); logs = cur.fetchall()
    cur.close(); conn.close(); return render_template("admin_panel.html", sessions=sessions, logs=logs)


@app.route("/admin/session/<int:session_id>/revoke", methods=["POST"])
def admin_revoke_session(session_id):
    if not admin_required(): return redirect(url_for("admin_login"))
    conn = db_conn(); cur = conn.cursor(); cur.execute("SELECT ip_address::text FROM guest_sessions WHERE id=%s", (session_id,)); row = cur.fetchone()
    if row:
        ip_address = row[0]; ok, msg = remove_ip_from_fortigate(ip_address); cur.execute("UPDATE guest_sessions SET status='revoked', logout_time=CURRENT_TIMESTAMP WHERE id=%s", (session_id,)); conn.commit(); log_system("WARNING", "admin_session_revoked", f"Admin revoked session ID={session_id}, result={msg}", ip_address)
    cur.close(); conn.close(); return redirect(url_for("admin_panel"))


@app.route("/admin/session/<int:session_id>/permanent", methods=["POST"])
def admin_make_permanent(session_id):
    if not admin_required(): return redirect(url_for("admin_login"))
    conn = db_conn(); cur = conn.cursor(); cur.execute("UPDATE guest_sessions SET status='permanent', expire_time=NULL WHERE id=%s", (session_id,)); conn.commit(); cur.close(); conn.close(); return redirect(url_for("admin_panel"))


@app.route("/admin/logout")
def admin_logout(): session.clear(); return redirect(url_for("admin_login"))


@app.route("/privacy")
def privacy(): return render_template("privacy.html")


if __name__ == "__main__":
    init_db(); app.run(host="0.0.0.0", port=8080)
