import os, json, hashlib
from datetime import date, datetime, timezone
import psycopg2
from dotenv import load_dotenv
BASE_DIR = os.path.dirname(os.path.abspath(__file__)); load_dotenv(os.path.join(BASE_DIR, ".env")); OUT_DIR = os.path.join(BASE_DIR, "integrity"); os.makedirs(OUT_DIR, exist_ok=True)
DB_CONFIG = {"host": os.getenv("DB_HOST", "localhost"), "port": int(os.getenv("DB_PORT", "5432")), "dbname": os.getenv("DB_NAME", "guestportal"), "user": os.getenv("DB_USER", "guestuser"), "password": os.getenv("DB_PASSWORD", "")}
def sha256_text(text): return hashlib.sha256(text.encode("utf-8")).hexdigest()
def main():
    target_date = date.today().isoformat(); conn = psycopg2.connect(**DB_CONFIG); cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS integrity_hashes (id SERIAL PRIMARY KEY, hash_date DATE NOT NULL, source_name TEXT NOT NULL, record_count INTEGER NOT NULL, file_sha256 TEXT NOT NULL, chain_hash TEXT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)")
    cur.execute("SELECT id, full_name, phone, ip_address::text, mac_address, status, login_time, expire_time, logout_time FROM guest_sessions WHERE DATE(login_time)=CURRENT_DATE ORDER BY id ASC"); sessions = cur.fetchall()
    payload = {"generated_at": datetime.now(timezone.utc).isoformat(), "date": target_date, "sessions": [list(row) for row in sessions]}; data = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str, indent=2); file_hash = sha256_text(data)
    cur.execute("SELECT chain_hash FROM integrity_hashes ORDER BY id DESC LIMIT 1"); prev = cur.fetchone(); previous_chain = prev[0] if prev else "GENESIS"; chain_hash = sha256_text(previous_chain + file_hash)
    json_path = os.path.join(OUT_DIR, f"guest_portal_{target_date}.json"); hash_path = os.path.join(OUT_DIR, f"guest_portal_{target_date}.sha256")
    open(json_path, "w", encoding="utf-8").write(data); open(hash_path, "w", encoding="utf-8").write(f"file_sha256={file_hash}\nchain_hash={chain_hash}\n")
    cur.execute("INSERT INTO integrity_hashes (hash_date, source_name, record_count, file_sha256, chain_hash) VALUES (CURRENT_DATE, %s, %s, %s, %s)", ("guest_portal_daily", len(sessions), file_hash, chain_hash)); conn.commit(); cur.close(); conn.close(); print(json_path); print(hash_path)
if __name__ == "__main__": main()
