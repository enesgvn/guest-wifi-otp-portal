# Deployment Notes

Use HTTPS, strong secrets, a dedicated FortiGate API account, and a real SMS gateway before production use.
