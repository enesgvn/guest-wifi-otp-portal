# FortiGate Notes

## Objects

Create an address group similar to `Guest_SMS_Allowed`.

The application creates dynamic IP address objects named like `GUEST_10_20_30_40` and adds them to the configured group.

## Captive portal concept

This design does not create a native FortiGate user login session. Instead, it uses an external OTP portal and then updates a FortiGate address group through the API.

Because of this, mobile captive portal mini-browsers may not always close automatically. The success page silently redirects to a configured test URL after 5 seconds.

## Recommended policy order

```text
1. Guest interface -> Portal server, service TCP/8080, accept
2. Guest interface -> WAN, source Guest_SMS_Allowed, NAT enabled, accept
3. Guest interface -> internal networks, deny
```

## IP/MAC safety logic

- Same IP + same MAC: keep session
- Same IP + different MAC: remove from FortiGate group and mark `mac_mismatch`
- DHCP lease not visible: keep session temporarily and log warning
- Session expired: remove from FortiGate group and mark `expired`
- FortiGate group member without active DB session: remove as orphan
- Permanent session MAC found on new IP: move the FortiGate permission to the new IP
