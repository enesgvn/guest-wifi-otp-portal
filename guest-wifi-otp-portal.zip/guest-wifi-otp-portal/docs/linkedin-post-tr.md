# LinkedIn paylaşım metni

Misafir Wi-Fi erişimi için SMS OTP doğrulama, IP/MAC oturum takibi ve FortiGate API entegrasyonunu içeren self-hosted bir portal geliştirdim.

Proje özeti:

- Flask tabanlı captive portal
- PostgreSQL ile oturum ve audit log kaydı
- SMS OTP doğrulama akışı
- FortiGate address group API entegrasyonu
- IP + MAC eşleşme kontrolü
- Süresi dolan veya IP/MAC eşleşmesi bozulan oturumların otomatik temizlenmesi
- Kalıcı cihazlar için MAC bazlı IP taşıma mantığı
- Günlük SHA-256 bütünlük hash zinciri
- Basit admin paneli
- Docker ve systemd kurulum örnekleri

Bu yapı sayesinde doğrulanan misafir kullanıcılar belirlenen süre boyunca internete çıkabiliyor. Aynı IP farklı bir MAC adresine geçtiğinde erişim otomatik olarak kesiliyor.

Projeyi kurum bilgileri, IP adresleri ve özel anahtarlar olmadan genel kullanıma uygun hale getirdim.

#CyberSecurity #NetworkSecurity #Fortinet #FortiGate #Python #Flask #PostgreSQL #WiFi #CaptivePortal #OpenSource
