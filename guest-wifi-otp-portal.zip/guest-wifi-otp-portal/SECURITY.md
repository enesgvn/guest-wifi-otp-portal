# Security Policy

Do not open public issues containing production secrets, firewall addresses, API tokens, customer records, or logs.
