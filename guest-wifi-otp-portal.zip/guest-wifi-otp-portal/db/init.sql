CREATE DATABASE guestportal;
CREATE USER guestuser WITH PASSWORD 'change-me';
GRANT ALL PRIVILEGES ON DATABASE guestportal TO guestuser;
